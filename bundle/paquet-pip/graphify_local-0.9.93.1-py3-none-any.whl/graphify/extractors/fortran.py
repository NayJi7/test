"""Fortran extractor. Moved verbatim from graphify/extract.py."""
from __future__ import annotations


import re
from pathlib import Path
from graphify.extractors.base import _file_stem, _make_id, _read_source_bytes, _read_text


_FORTRAN_CPP_EXTS = {".F", ".F90", ".F95", ".F03", ".F08"}

# A cpp `#include` directive at the start of a (optionally indented) line, in
# either the `"..."` or `<...>` form. Matched on raw bytes before preprocessing.
_INCLUDE_DIRECTIVE_RE = re.compile(rb"^[ \t]*#[ \t]*include\b")


def _strip_include_directives(source: bytes) -> bytes:
    """Blank every cpp `#include` directive, preserving line numbers.

    cpp always searches the directory of the file being preprocessed for quoted
    includes and always honours absolute include paths, regardless of
    `-nostdinc`/`-I` — so a malicious capital-F Fortran source containing
    `#include "/etc/passwd"` or `#include "../../../secret"` would inline
    arbitrary host files into the graph we ship to the LLM and persist to disk
    (GHSA-pcc4-rvhr-2pr8, CWE-22/73/200). The `-nostdinc -I /dev/null` mitigation
    did not cover those two cases. Removing the directives entirely keeps macro
    expansion (the reason capital-F files need cpp — `#ifdef MPI`, `#define
    REAL8`) while making host-file reads impossible. Cross-file include fidelity
    is lost, which is an acceptable trade for closing an arbitrary-read vector on
    the default offline path. Each stripped line is blanked (not deleted) so
    reported line numbers still match the original source.
    """
    return b"\n".join(
        b"" if _INCLUDE_DIRECTIVE_RE.match(line) else line
        for line in source.split(b"\n")
    )


def _cpp_preprocess(path: Path) -> bytes:
    """Run cpp -w -P on a capital-F Fortran file and return preprocessed bytes.

    Falls back to (include-stripped) raw file bytes if cpp is not available.
    Capital-F extensions conventionally require C preprocessor expansion
    (#ifdef MPI, #define REAL8, etc.) before parsing.

    Security (GHSA-pcc4-rvhr-2pr8): every `#include` directive is stripped before
    preprocessing (see `_strip_include_directives`) and the sanitized source is
    fed to cpp on stdin, so cpp never opens the source file's directory or any
    absolute/traversing include path — closing the corpus-side arbitrary
    file-read/exfiltration vector that `-nostdinc -I /dev/null` alone left open.
    Feeding stdin (rather than a file path) also removes the `-I/etc/x.F90`
    argument-injection edge case entirely.
    """
    import shutil
    import subprocess
    safe = _strip_include_directives(_read_source_bytes(path))
    if not shutil.which("cpp"):
        return safe
    try:
        result = subprocess.run(
            ["cpp", "-w", "-P", "-nostdinc", "-I", "/dev/null"],
            input=safe,
            capture_output=True,
            timeout=30,
        )
        if result.returncode == 0 and result.stdout:
            return result.stdout
    except Exception:
        pass
    return safe

def extract_fortran(path: Path) -> dict:
    """Extract programs, modules, subroutines, functions, use statements, and calls from Fortran files.

    Capital-F extensions (.F, .F90, etc.) are run through the C preprocessor before
    parsing so #ifdef/#define macros are resolved.
    """
    try:
        import tree_sitter_fortran as tsfortran
        from tree_sitter import Language, Parser
    except ImportError:
        return {"nodes": [], "edges": [], "error": "tree-sitter-fortran not installed"}

    try:
        language = Language(tsfortran.language())
        parser = Parser(language)
        source = _cpp_preprocess(path) if path.suffix in _FORTRAN_CPP_EXTS else _read_source_bytes(path)
        tree = parser.parse(source)
        root = tree.root_node
    except Exception as e:
        return {"nodes": [], "edges": [], "error": str(e)}

    stem = _file_stem(path)
    str_path = str(path)
    nodes: list[dict] = []
    edges: list[dict] = []
    seen_ids: set[str] = set()
    scope_bodies: list[tuple[str, object]] = []

    def add_node(nid: str, label: str, line: int) -> None:
        if nid not in seen_ids:
            seen_ids.add(nid)
            nodes.append({
                "id": nid,
                "label": label,
                "file_type": "code",
                "source_file": str_path,
                "source_location": f"L{line}",
            })

    def add_edge(src: str, tgt: str, relation: str, line: int,
                 confidence: str = "EXTRACTED", weight: float = 1.0,
                 context: str | None = None) -> None:
        edge = {
            "source": src,
            "target": tgt,
            "relation": relation,
            "confidence": confidence,
            "source_file": str_path,
            "source_location": f"L{line}",
            "weight": weight,
        }
        if context:
            edge["context"] = context
        edges.append(edge)

    file_nid = _make_id(str(path))
    add_node(file_nid, path.name, 1)

    # (type_nid, implementing_procedure_name, line) for every type-bound
    # procedure. Resolved after the whole tree is walked, once the module's
    # internal procedures have their nodes.
    type_bound_procs: list[tuple[str, str, int]] = []
    # (generic_nid, specific_procedure_name, line) for each procedure grouped
    # under a named generic interface. Resolved after the walk, like the
    # type-bound procedures above.
    generic_procs: list[tuple[str, str, int]] = []

    def _fortran_name(stmt_node) -> str | None:
        """Extract name from a *_statement node. Fortran is case-insensitive; lowercase."""
        for child in stmt_node.children:
            if child.type in ("name", "identifier"):
                return _read_text(child, source).lower()
        return None

    def ensure_named_node(name: str, line: int) -> str:
        nid = _make_id(stem, name)
        if nid in seen_ids:
            return nid
        nid = _make_id(name)
        if nid not in seen_ids:
            # The name isn't defined in this file, so this is a cross-file reference
            # (e.g. a `Thing` type annotation imported from another module). Emit a
            # SOURCELESS stub — like the inheritance-base path below — so the
            # corpus-level rewire can collapse it onto the real definition. A sourced
            # stub here makes _disambiguate_colliding_node_ids bake the referencing
            # file's path (with extension) into the id and blocks the rewire, which is
            # the phantom-duplicate-node bug (#1402).
            seen_ids.add(nid)
            nodes.append({
                "id": nid,
                "label": name,
                "file_type": "code",
                "source_file": "",
                "source_location": "",
                "origin_file": str_path,
            })
        return nid

    def emit_signature_refs(scope_node, fn_nid: str, is_function: bool) -> None:
        """Emit references[parameter_type] / references[return_type] edges for
        a subroutine/function based on its variable_declaration siblings."""
        stmt_type = "function_statement" if is_function else "subroutine_statement"
        stmt = next((c for c in scope_node.children if c.type == stmt_type), None)
        if stmt is None:
            return
        param_names: set[str] = set()
        params_node = next((c for c in stmt.children if c.type == "parameters"), None)
        if params_node is not None:
            for c in params_node.children:
                if c.type == "identifier":
                    param_names.add(_read_text(c, source).lower())
        result_name: str | None = None
        if is_function:
            result_node = next((c for c in stmt.children if c.type == "function_result"), None)
            if result_node is not None:
                res_id = next((c for c in result_node.children if c.type == "identifier"), None)
                if res_id is not None:
                    result_name = _read_text(res_id, source).lower()
            else:
                # implicit result variable: same name as the function
                result_name = _fortran_name(stmt)
        for child in scope_node.children:
            if child.type != "variable_declaration":
                continue
            derived = next((c for c in child.children if c.type == "derived_type"), None)
            if derived is None:
                continue
            type_name_node = next((c for c in derived.children if c.type == "type_name"), None)
            if type_name_node is None:
                continue
            type_name = _read_text(type_name_node, source).lower()
            for var in child.children:
                if var.type != "identifier":
                    continue
                var_name = _read_text(var, source).lower()
                var_line = var.start_point[0] + 1
                if var_name in param_names:
                    tgt = ensure_named_node(type_name, var_line)
                    if tgt != fn_nid:
                        add_edge(fn_nid, tgt, "references", var_line, context="parameter_type")
                elif is_function and var_name == result_name:
                    tgt = ensure_named_node(type_name, var_line)
                    if tgt != fn_nid:
                        add_edge(fn_nid, tgt, "references", var_line, context="return_type")

    def _type_bound_impl_name(proc_stmt) -> str | None:
        """The module procedure implementing a type-bound `procedure` statement.

        `procedure :: area => circle_area` binds the method name `area` to the
        implementation `circle_area` (a `binding` node with a `method_name`
        child); `procedure :: scale` binds `scale` to a same-named procedure
        (a bare `method_name` child)."""
        binding = next((c for c in proc_stmt.children if c.type == "binding"), None)
        if binding is not None:
            mn = next((c for c in binding.children if c.type == "method_name"), None)
            if mn is not None:
                return _read_text(mn, source).lower()
        mn = next((c for c in proc_stmt.children if c.type == "method_name"), None)
        if mn is not None:
            return _read_text(mn, source).lower()
        return None

    def walk_calls(node, scope_nid: str) -> None:
        if node is None:
            return
        t = node.type
        if t in ("subroutine", "function", "module", "program", "internal_procedures"):
            return
        # call FOO(args) — tree-sitter-fortran uses subroutine_call
        if t == "subroutine_call":
            name_node = next((c for c in node.children if c.type == "identifier"), None)
            if name_node:
                callee = _read_text(name_node, source).lower()
                target_nid = _make_id(stem, callee)
                add_edge(scope_nid, target_nid, "calls", node.start_point[0] + 1,
                         confidence="EXTRACTED", context="call")
        # x = compute(args) — function invocations are `call_expression`, which
        # shares Fortran's `name(...)` syntax with array indexing. Only emit a
        # call edge when the callee resolves to a procedure defined in this file
        # (an array variable produces no matching node), so array accesses can't
        # fabricate spurious `calls` edges.
        elif t == "call_expression":
            name_node = next((c for c in node.children if c.type == "identifier"), None)
            if name_node:
                callee = _read_text(name_node, source).lower()
                target_nid = _make_id(stem, callee)
                if target_nid in seen_ids and target_nid != scope_nid:
                    add_edge(scope_nid, target_nid, "calls", node.start_point[0] + 1,
                             confidence="EXTRACTED", context="call")
        for child in node.children:
            walk_calls(child, scope_nid)

    def walk(node, scope_nid: str) -> None:
        t = node.type

        if t == "program":
            stmt = next((c for c in node.children if c.type == "program_statement"), None)
            name = _fortran_name(stmt) if stmt else None
            if name:
                nid = _make_id(stem, name)
                line = node.start_point[0] + 1
                add_node(nid, name, line)
                add_edge(file_nid, nid, "defines", line)
                scope_bodies.append((nid, node))
                for child in node.children:
                    walk(child, nid)
            return

        if t == "module":
            stmt = next((c for c in node.children if c.type == "module_statement"), None)
            name = _fortran_name(stmt) if stmt else None
            if name:
                nid = _make_id(stem, name)
                line = node.start_point[0] + 1
                add_node(nid, name, line)
                add_edge(file_nid, nid, "defines", line)
                for child in node.children:
                    walk(child, nid)
            return

        # subroutines/functions inside a module live under internal_procedures
        if t == "internal_procedures":
            for child in node.children:
                walk(child, scope_nid)
            return

        if t == "derived_type_definition":
            stmt = next((c for c in node.children if c.type == "derived_type_statement"), None)
            if stmt is not None:
                name_node = next((c for c in stmt.children if c.type == "type_name"), None)
                if name_node is not None:
                    type_name = _read_text(name_node, source).lower()
                    type_nid = _make_id(stem, type_name)
                    line = node.start_point[0] + 1
                    add_node(type_nid, type_name, line)
                    add_edge(scope_nid, type_nid, "defines", line)
                    # Type-bound procedures in the `contains` section bind the
                    # derived type to the module procedures that implement its
                    # methods. Without this the binding was dropped and the type
                    # sat in the graph with no link to its own methods.
                    procs = next((c for c in node.children
                                  if c.type == "derived_type_procedures"), None)
                    if procs is not None:
                        for stmt in procs.children:
                            if stmt.type != "procedure_statement":
                                continue
                            impl = _type_bound_impl_name(stmt)
                            if impl:
                                type_bound_procs.append(
                                    (type_nid, impl, stmt.start_point[0] + 1))
            return

        if t == "subroutine":
            stmt = next((c for c in node.children if c.type == "subroutine_statement"), None)
            name = _fortran_name(stmt) if stmt else None
            if name:
                nid = _make_id(stem, name)
                line = node.start_point[0] + 1
                add_node(nid, f"{name}()", line)
                add_edge(scope_nid, nid, "defines", line)
                scope_bodies.append((nid, node))
                emit_signature_refs(node, nid, is_function=False)
                for child in node.children:
                    walk(child, nid)
            return

        if t == "function":
            stmt = next((c for c in node.children if c.type == "function_statement"), None)
            name = _fortran_name(stmt) if stmt else None
            if name:
                nid = _make_id(stem, name)
                line = node.start_point[0] + 1
                add_node(nid, f"{name}()", line)
                add_edge(scope_nid, nid, "defines", line)
                scope_bodies.append((nid, node))
                emit_signature_refs(node, nid, is_function=True)
                for child in node.children:
                    walk(child, nid)
            return

        if t == "interface":
            stmt = next((c for c in node.children
                         if c.type == "interface_statement"), None)
            name_node = next((c for c in stmt.children if c.type == "name"),
                             None) if stmt is not None else None
            if name_node is not None:
                # Named generic interface (`interface area; module procedure
                # area_circle, area_square; end interface`): `area` is a callable
                # generic name that dispatches to its specific procedures by
                # argument type. It was never a node, so every `area(...)` call
                # dangled — a function call_expression only resolves to an
                # in-file node. Emit the generic node and link it to the
                # procedures it groups, so calls resolve and the dispatch set is
                # visible.
                gen_name = _read_text(name_node, source).lower()
                gen_nid = _make_id(stem, gen_name)
                line = node.start_point[0] + 1
                add_node(gen_nid, f"{gen_name}()", line)
                add_edge(scope_nid, gen_nid, "defines", line)
                for proc_stmt in node.children:
                    if proc_stmt.type != "procedure_statement":
                        continue
                    for mn in proc_stmt.children:
                        if mn.type == "method_name":
                            generic_procs.append((
                                gen_nid,
                                _read_text(mn, source).lower(),
                                proc_stmt.start_point[0] + 1,
                            ))
                return
            # Unnamed abstract/explicit interface: recurse so the procedure
            # declarations it holds still get nodes (unchanged behaviour).
            for child in node.children:
                walk(child, scope_nid)
            return

        if t == "use_statement":
            line = node.start_point[0] + 1
            # tree-sitter-fortran uses module_name node for the used module
            name_node = next((c for c in node.children if c.type in ("module_name", "name", "identifier")), None)
            if name_node:
                mod_name = _read_text(name_node, source).lower()
                imp_nid = _make_id(mod_name)
                add_node(imp_nid, mod_name, line)
                add_edge(scope_nid, imp_nid, "imports", line, context="use")
            return

        for child in node.children:
            walk(child, scope_nid)

    walk(root, file_nid)

    # Link each derived type to the procedures bound as its methods, now that
    # the module's internal procedures have been given nodes. A binding to a
    # procedure imported from another module resolves to a sourceless stub the
    # corpus rewire can collapse (same treatment as parameter/return types).
    for type_nid, impl_name, line in type_bound_procs:
        tgt = ensure_named_node(impl_name, line)
        if tgt != type_nid:
            add_edge(type_nid, tgt, "method", line, context="type_bound_procedure")

    # Link each generic interface to the specific procedures it groups. A
    # procedure imported from another module resolves to a sourceless stub the
    # corpus rewire can collapse (same treatment as type-bound procedures).
    for gen_nid, impl_name, line in generic_procs:
        tgt = ensure_named_node(impl_name, line)
        if tgt != gen_nid:
            add_edge(gen_nid, tgt, "dispatches_to", line,
                     context="generic_interface")

    _stmt_headers = {
        "subroutine_statement", "function_statement",
        "program_statement", "module_statement",
    }
    for scope_nid, body_node in scope_bodies:
        for child in body_node.children:
            if child.type not in _stmt_headers:
                walk_calls(child, scope_nid)

    return {"nodes": nodes, "edges": edges}
