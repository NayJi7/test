#  Copyright 2008-2015 Nokia Networks
#  Copyright 2016-     Robot Framework Foundation
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

import copy
import re
from collections.abc import Iterator
from pathlib import Path
from typing import Any, Callable, NoReturn, TYPE_CHECKING
from xml.etree import ElementTree as ET

try:
    from lxml import etree as lxml_etree
except ImportError:
    lxml_etree = None
else:
    # `lxml.etree._Attrib` doesn't extend `Mapping` and thus our `is_dict_like`
    # doesn't recognize it unless we register it ourselves. Fixed in lxml 4.9.2:
    # https://bugs.launchpad.net/lxml/+bug/1981760
    from collections.abc import MutableMapping

    Attrib = getattr(lxml_etree, "_Attrib", None)
    if Attrib and not isinstance(Attrib, MutableMapping):
        MutableMapping.register(Attrib)  # type: ignore
    del Attrib, MutableMapping

from robot.api import logger
from robot.api.deco import library
from robot.libraries.BuiltIn import BuiltIn
from robot.utils import asserts, ETSource, plural_or_not as s
from robot.version import get_version

should_be_equal = asserts.assert_equal
should_match = BuiltIn().should_match


if TYPE_CHECKING:
    Source = Any
    Element = Any

else:

    class Source:
        """XML source.

        Can be given as a path to an XML file, as a string or bytes containing
        XML data, or as an already parsed XML element structure.

        ```robotframework
        *** Test Cases ***
        Example
            # Give source as a path:
            ${xml} =    Parse XML    ${CURDIR}/example.xml
            # Give source as an already parsed element:
            ${elem} =    Get Element    ${xml}    xpath=child
            # Give source as a string:
            Elements Should Be Equal    ${elem}    <child>text</child>
        ```
        """

    class Element:
        """A parsed XML element.

        Represented as an ElementTree [Element] object. Can be used as a
        `source` argument with keywords modifying or validating XML elements.
        or validating XML elements. In addition to that, attributes like `text`
        can be accessed using the extended variable syntax like `${elem.text}`
        directly.

        ```robotframework
        *** Test Cases ***
        Example
            # Get element as a return value:
            ${elem} =    Parse XML    ${CURDIR}/example.xml
            # Use element as an argument with other keywords:
            ${child} =    Get Element    ${elem}    expath=child
            # Access element attributes:
            Log    ${elem.text}
        ```

        [Element]: https://docs.python.org/3/library/xml.etree.elementtree.html#xml.etree.ElementTree.Element "API docs"
        """


@library(
    scope="GLOBAL",
    version=get_version(),
    doc_format="MARKDOWN",
    converters={Source: lambda value: value, Element: lambda value: value},
    auto_keywords=True,
)
class XML:
    r"""Robot Framework library for verifying and modifying XML documents.

    As the name implies, *XML* is a library for verifying contents of XML files.
    In practice, it is a pretty thin wrapper on top of Python's
    [ElementTree XML API].

    The library has the following main usages:

    - Parsing an XML file, or a string containing XML, into an XML element
      structure and finding certain elements from it for further analysis
      (e.g. [Parse XML] and [Get Element] keywords).
    - Getting text or attributes of elements
      (e.g. [Get Element Text] and [Get Element Attribute]).
    - Directly verifying text, attributes, or whole elements
      (e.g [Element Text Should Be] and [Elements Should Be Equal]).
    - Modifying XML and saving it (e.g. [Set Element Text], [Add Element]
      and [Save XML]).

    ### Table of contents

    %TOC%

    # Parsing XML

    XML can be parsed into an element structure using [Parse XML] keyword.
    The XML to be parsed can be specified using a path to an XML file or as
    a string or bytes that contain XML directly. The keyword returns the root
    element of the structure, which then contains other elements as its
    children and their children. Possible comments and processing instructions
    in the source XML are removed.

    XML is not validated during parsing even if it has a schema defined. How
    possible doctype elements are handled otherwise depends on the used XML
    module and on the platform. The standard ElementTree strips doctypes
    altogether, but when [using lxml] they are preserved when XML is saved.

    The element structure returned by [Parse XML], as well as elements
    returned by keywords such as [Get Element], can be used as the `source`
    argument with other keywords. In addition to an already parsed XML
    structure, other keywords also accept paths to XML files and strings
    containing XML similarly as [Parse XML]. Notice that keywords that modify
    XML do not write those changes back to disk even if the source would be
    given as a path to a file. Changes must always be saved explicitly using
    [Save XML] keyword.

    When the source is given as a path to a file, the forward slash character
    (`/`) can be used as the path separator regardless the operating system.
    On Windows also the backslash works, but in the data it needs to be
    escaped by doubling it (`\\`). Using the built-in variable `${/}`
    naturally works too.

    # Using lxml

    By default, this library uses Python's standard [ElementTree] module for
    parsing XML, but it can be configured to use [lxml] module instead when
    [importing] the library. The resulting element structure has same API
    regardless which module is used for parsing.

    The main benefits of using lxml is that it supports richer xpath syntax
    than the standard ElementTree and enables using [Evaluate Xpath] keyword.
    It also preserves the doctype and possible namespace prefixes saving XML.

    # Example

    The following simple example demonstrates parsing XML and verifying its
    contents. How to use xpath expressions to find elements and what attributes
    the returned elements contain are discussed, with more examples, in
    [Finding elements with xpath] and [Element attributes] sections.

    In this example, as well as in many other examples in this documentation,
    `${XML}` refers to the following example XML document. In practice `${XML}`
    could either be a path to an XML file or it could contain the XML itself.

    ```xml
    <example>
        <first id="1">text</first>
        <second id="2">
            <child />
        </second>
        <third>
            <child>more text</child>
            <second id="child" />
            <child>
                <grandchild />
            </child>
        </third>
        <html>
            <p>
                Text with <b>bold</b> and <i>italics</i>.
            </p>
        </html>
    </example>
    ```

    ```robotframework
    *** Settings ***
    Library         XML    use_xml=True

    *** Test Cases ***
    Example
        ${root} =    Parse XML    ${XML}
        Should Be Equal    ${root.tag}    example
        ${first} =    Get Element    ${root}    first
        Should Be Equal    ${first.text}    text
        Element Text Should Be    ${first}    text
        Element Attribute Should Be    ${first}    id    1
        Element Attribute Should Be    ${root}     id    1    xpath=first
        Element Attribute Should Be    ${XML}      id    1    xpath=first
    ```

    Notice that in the example three last lines are equivalent. Which one to
    use in practice depends on which other elements you need to get or verify.
    If you only need to do one verification, using the last line alone would
    suffice. If more verifications are needed, parsing the XML with [Parse XML]
    only once would be more efficient.

    # Finding elements with xpath

    ElementTree, and thus also this library, supports finding elements using
    xpath expressions. ElementTree does not, however, support the full xpath
    standard. The supported xpath syntax is explained below and
    [ElementTree documentation] provides more details. In the examples
    `${XML}` refers to the same XML structure as in the earlier example.

    If lxml support is enabled when [importing] the library, the whole
    [xpath 1.0 standard] is supported. That includes everything listed below
    but also a lot of other useful constructs.

    ## Tag names

    When just a single tag name is used, xpath matches all direct child
    elements that have that tag name.

    ```robotframework
    *** Test Cases ***
    Tag names
        ${elem} =    Get Element    ${XML}    third
        Should Be Equal    ${elem.tag}    third
        @{children} =    Get Elements    ${elem}    child
        Length Should Be    ${children}    2
    ```

    ## Paths

    Paths are created by combining tag names with a forward slash (`/`). For
    example, `parent/child` matches all `child` elements under `parent`
    element. Notice that if there are multiple `parent` elements that all
    have `child` elements, `parent/child` xpath will match all these
    `child` elements.

    ```robotframework
    *** Test Cases ***
    Paths
        ${elem} =    Get Element    ${XML}    second/child
        Should Be Equal    ${elem.tag}    child
        ${elem} =    Get Element    ${XML}    third/child/grandchild
        Should Be Equal    ${elem.tag}    grandchild
    ```

    ## Wildcards

    An asterisk (`*`) can be used in paths instead of a tag name to denote
    any element.

    ```robotframework
    *** Test Cases ***
    Wildcards
        @{children} =    Get Elements    ${XML}    */child
        Length Should Be    ${children}    3
    ```

    ## Current element

    The current element is denoted with a dot (`.`). Normally the current
    element is implicit and does not need to be included in the xpath.

    ## Parent element

    The parent element of another element is denoted with two dots (`..`).
    Notice that it is not possible to refer to the parent of the current
    element.

    ```robotframework
    *** Test Cases ***
    Parent element
        ${elem} =    Get Element    ${XML}    */second/..
        Should Be Equal    ${elem.tag}    third
    ```

    ## Search all sub elements

    Two forward slashes (`//`) mean that all sub elements, not only the
    direct children, are searched. If the search is started from the current
    element, an explicit dot is required.

    ```robotframework
    *** Test Cases ***
    Search all sub elements
        @{elements} =    Get Elements    ${XML}    .//second
        Length Should Be    ${elements}    2
        ${b} =    Get Element    ${XML}    html//b
        Should Be Equal    ${b.text}    bold
    ```

    ## Predicates

    Predicates allow selecting elements using also other criteria than tag
    names, for example, attributes or position. They are specified after the
    normal tag name or path using syntax `path[predicate]`. The path can have
    wildcards and other special syntax explained earlier. What predicates
    the standard ElementTree supports is explained in the table below.

    |    Predicate    |                    Matches                            |          Example          |
    | --------------- | ------------------------------------------------------| ------------------------- |
    | `@attr`         | Elements with attribute `attr`.                       | `second[@id]`             |
    | `@attr="value"` | Elements with attribute `attr` having value `value`.  | `*[@id="2"]`              |
    | `position`      | Elements at the specified position.                   | `third/child[1]`          |
    | `tag`           | Elements with a child element named `tag`.            | `third/child[grandchild]` |

    `position` can be an integer starting from 1, expression `last()`, or
    a relative expression like `last() - 1`.

    Predicates can also be stacked like `path[predicate1][predicate2]`.
    A limitation is that possible position predicate must always be first.

    # Element attributes

    All keywords returning elements, such as [Parse XML], and [Get Element],
    return ElementTree's [Element objects]. These elements can be used as
    inputs for other keywords, but they also contain several useful attributes
    that can be accessed directly using the extended variable syntax.

    The attributes that are both useful and convenient to use in the data
    are explained below. Other attributes, including methods, can also
    be accessed, but that is typically better to do in custom libraries than
    directly in the data.

    The examples use the same `${XML}` structure as the earlier examples.

    ## tag

    The tag of the element.

    ```robotframework
    *** Test Cases ***
    Tag
        ${root} =    Parse XML    ${XML}
        Should Be Equal    ${root.tag}    example
    ```

    ## text

    The text that the element contains or Python `None` if the element has no
    text. Notice that the text *does not* contain texts of possible child
    elements nor text after or between children. Notice also that in XML
    whitespace is significant, so the text contains also possible indentation
    and newlines. To get also text of the possible children, optionally
    whitespace normalized, use [Get Element Text] keyword.

    ```robotframework
    *** Test Cases ***
    Text
        ${1st} =    Get Element    ${XML}    first
        Should Be Equal    ${1st.text}    text
        ${2nd} =    Get Element    ${XML}    second/child
        Should Be Equal    ${2nd.text}    ${NONE}
        ${p} =    Get Element    ${XML}    html/p
        Should Be Equal    ${p.text}    \n${SPACE*12}Text with${SPACE}
    ```

    ## tail

    The text after the element before the next opening or closing tag. Python
    `None` if the element has no tail. Similarly as with `text`, also
    `tail` contains possible indentation and newlines.

    ```robotframework
    *** Test Cases ***
    Tail
        ${b} =    Get Element    ${XML}    html/p/b
        Should Be Equal    ${b.tail}    ${SPACE}and${SPACE}
    ```

    ## attrib

    A Python dictionary containing attributes of the element.

    ```robotframework
    *** Test Cases ***
    Attrib
        ${2nd} =    Get Element    ${XML}    second
        Should Be Equal    ${2nd.attrib['id']}    2
        ${3rd} =    Get Element    ${XML}    third
        Should Be Empty    ${3rd.attrib}
    ```

    # Handling XML namespaces

    ElementTree and lxml handle possible namespaces in XML documents by adding
    the namespace URI to tag names in so-called Clark Notation. That is
    inconvenient especially with xpaths, and by default this library strips
    those namespaces away and moves them to `xmlns` attribute instead. That
    can be avoided by passing `keep_clark_notation` argument to [Parse XML]
    keyword. Alternatively [Parse XML] supports stripping namespace information
    altogether by using `strip_namespaces` argument. The pros and cons of
    different approaches are discussed in more detail below.

    ## How ElementTree handles namespaces

    If an XML document has namespaces, ElementTree adds namespace information
    to tag names in [Clark Notation] (e.g. `{http://ns.uri}tag`) and removes
    original `xmlns` attributes. This is done both with default namespaces
    and with namespaces with a prefix. How it works in practice is illustrated
    by the following example, where the `${NS}` variable contains this XML
    document:

    ```xml
    <xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                    xmlns="http://www.w3.org/1999/xhtml">
        <xsl:template match="/">
            <html></html>
        </xsl:template>
    </xsl:stylesheet>
    ```

    ```robotframework
    *** Test Cases ***
    Using Clark notation
        ${root} =    Parse XML    ${NS}    keep_clark_notation=True
        Should Be Equal    ${root.tag}    {http://www.w3.org/1999/XSL/Transform}stylesheet
        Element Should Exist    ${root}    {http://www.w3.org/1999/XSL/Transform}template/{http://www.w3.org/1999/xhtml}html
        Should Be Empty    ${root.attrib}
    ```

    As you can see, including the namespace URI in tag names makes xpaths
    really long and complex.

    If you save the XML, ElementTree moves namespace information back to
    `xmlns` attributes. Unfortunately it does not restore the original
    prefixes and you get something like this:

    ```xml
    <ns0:stylesheet xmlns:ns0="http://www.w3.org/1999/XSL/Transform">
        <ns0:template match="/">
            <ns1:html xmlns:ns1="http://www.w3.org/1999/xhtml"></ns1:html>
        </ns0:template>
    </ns0:stylesheet>
    ```

    The resulting output is semantically same as the original, but mangling
    prefixes like this may still not be desirable. Notice also that the actual
    output depends also on the ElementTree version.

    ## Default namespace handling

    Because the way ElementTree handles namespaces makes xpaths so complicated,
    this library, by default, strips namespaces from tag names and moves that
    information back to `xmlns` attributes. How this works in practice is
    shown by the example below, where `${NS}` variable contains the same XML
    document as in the previous example.

    ```robotframework
    *** Test Cases ***
    Default namespace handling
        ${root} =    Parse XML    ${NS}
        Should Be Equal    ${root.tag}    stylesheet
        Element Should Exist    ${root}    template/html
        Element Attribute Should Be    ${root}    xmlns    http://www.w3.org/1999/XSL/Transform
        Element Attribute Should Be    ${root}    xmlns    http://www.w3.org/1999/xhtml    xpath=template/html
    ```

    Now that tags do not contain namespace information, xpaths are simple again.

    A minor limitation of this approach is that namespace prefixes are lost.
    As a result the saved output is not exactly same as the original one in
    this case either:

    ```xml
    <stylesheet xmlns="http://www.w3.org/1999/XSL/Transform">
        <template match="/">
            <html xmlns="http://www.w3.org/1999/xhtml"/>
        </template>
    </stylesheet>
    ```

    This output is semantically same as the original as well. If the original XML
    had only default namespaces, the output would also look identical.

    ## Namespaces when using lxml

    This library handles namespaces same way both when [using lxml] and when
    not using it. There are, however, differences how lxml internally handles
    namespaces compared to the standard ElementTree. The main difference is
    that lxml stores information about namespace prefixes, and they are thus
    preserved if XML is saved. Another visible difference is that lxml includes
    namespace information in child elements got with [Get Element] if the
    parent element has namespaces.

    ## Stripping namespaces altogether

    Because namespaces often add unnecessary complexity, [Parse XML] supports
    stripping them altogether by using `strip_namespaces=True`. When this
    option is enabled, namespaces are not shown anywhere nor are they included
    if XML is saved.

    ## Attribute namespaces

    Attributes in XML documents are, by default, in the same namespaces as
    the element they belong to. It is possible to use different namespaces
    by using prefixes, but this is pretty rare.

    If an attribute has a namespace prefix, ElementTree will replace it with
    Clark Notation the same way it handles elements. Because stripping
    namespaces from attributes could cause attribute conflicts, this library
    does not handle attribute namespaces at all. The following example thus
    works the same way regardless how namespaces are handled.

    ```robotframework
    *** Test Cases ***
    Attribute namespaces
        ${root} =    Parse XML    <root id="1" ns:id="2" xmlns:ns="http://my.ns"/>
        Element Attribute Should Be    ${root}    id    1
        Element Attribute Should Be    ${root}    {http://my.ns}id    2
    ```

    ## Pattern matching

    Some keywords, for example [Elements Should Match], support so called
    [glob patterns] where:

    |  Wildcard  |                    Description                         |
    | ---------- | ------------------------------------------------------ |
    | `*`        | Matches any string, even an empty string.              |
    | `?`        | Matches any single character.                          |
    | `[chars]`  | Matches one character in the bracket.                  |
    | `[!chars]` | Matches one character not in the bracket.              |
    | `[a-z]`    | Matches one character in the range in the bracket.     |
    | `[!a-z]`   | Matches one character not in the range in the bracket. |

    Unlike with glob patterns normally, path separator characters `/` and
    `\` and the newline character `\n` are matches by the above
    wildcards.

    [ElementTree XML API]: http://docs.python.org/library/xml.etree.elementtree.html "ElementTree XML API"
    [ElementTree]: http://docs.python.org/library/xml.etree.elementtree.html "ElementTree"
    [lxml]: http://lxml.de "lxml"
    [ElementTree documentation]: https://docs.python.org/library/xml.etree.elementtree.html#xpath-support "ElementTree documentation"
    [xpath 1.0 standard]: http://www.w3.org/TR/xpath/ "xpath 1.0 standard"
    [Element objects]: http://docs.python.org/library/xml.etree.elementtree.html#element-objects "Element objects"
    [Clark Notation]: http://www.jclark.com/xml/xmlns.htm "Clark Notation"
    [glob patterns]: http://en.wikipedia.org/wiki/Glob_(programming) "glob patterns"
    """

    def __init__(self, use_lxml: bool = False):
        """Import library with optionally lxml mode enabled.

        Args:
            use_lxml: Enable the lxml module for parsing XML instead of the
                standard ElementTree.

        This library uses Python's standard [ElementTree] module for parsing
        XML by default. If `use_lxml` argument is given a true value,
        the [lxml] module is used instead. See the [Using lxml] section for
        benefits provided by lxml.

        Using lxml requires that the lxml module is installed on the system.
        If lxml mode is enabled but the module is not installed, this library
        emits a warning and reverts back to using the standard ElementTree.
        """
        if use_lxml and lxml_etree:
            self.etree = lxml_etree  # type: ignore
            self.modern_etree = True
            self.lxml_etree = True
        else:
            self.etree = ET  # type: ignore
            self.modern_etree = ET.VERSION >= "1.3"
            self.lxml_etree = False
        if use_lxml and not lxml_etree:
            logger.warn(
                "XML library reverted to use standard ElementTree "
                "because lxml module is not installed."
            )
        self._ns_stripper = NameSpaceStripper(self.etree, self.lxml_etree)

    def parse_xml(
        self,
        source: Source,
        keep_clark_notation: bool = False,
        strip_namespaces: bool = False,
    ) -> Element:
        """Parses the given XML file or string into an element structure.

        Args:
            source: Path to an XML file or a string or bytes containing XML.
                Does not accept an already parsed element.
            keep_clark_notation: When true, namespace information is not
                removed from tag names.
            strip_namespaces: When true, namespace information is removed altogether.

        Returns:
            The root element of the parsed structure.

        The `source` can either be a path to an XML file or a string containing
        XML. In both cases the XML is parsed into ElementTree [Element] structure.
        Possible comments and processing instructions in the source XML are removed.

        As discussed in [Handling XML namespaces] section, this keyword, by
        default, removes namespace information ElementTree has added to tag
        names and moves it into `xmlns` attributes. This typically eases
        handling XML documents with namespaces considerably. If you do not
        want that to happen, or want to avoid the small overhead of going
        through the element structure, you can disable this feature by using
        the `keep_clark_notation` argument.

        If you want to strip namespace information altogether so that it is
        not included even if XML is saved, you can use the `strip_namespaces`
        argument.

        Examples:
        ```robotframework
        *** Test Cases ***
        Parse XML
            ${root} =    Parse XML    <root><child/></root>
            ${xml} =    Parse XML    ${CURDIR}/test.xml    keep_clark_notation=True
            ${xml} =    Parse XML    ${CURDIR}/test.xml    strip_namespaces=True
        ```

        Use [Get Element] keyword if you want to get a certain element and not
        the whole structure. See [Parsing XML] section for more details and
        examples.

        > [!NOTE]
        > This keyword does not accept an already parsed XML element as a source.
        > Use [Get Element] instead.
        """
        with ETSource(source) as source_:
            tree = self.etree.parse(source_)
        if self.lxml_etree:
            strip = (lxml_etree.Comment, lxml_etree.ProcessingInstruction)  # type: ignore
            lxml_etree.strip_elements(tree, *strip, with_tail=False)  # type: ignore
        root = tree.getroot()
        if not keep_clark_notation:
            self._ns_stripper.strip(root, preserve=not strip_namespaces)
        return root

    def get_element(self, source: Source, xpath: str = ".") -> Element:
        """Returns an element in the `source` matching the `xpath`.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression selecting the element to return.

        Returns:
            The matching element.

        Raises:
            AssertionError: If zero or more than one element matches.

        The `source` can be a path to an XML file, a string containing XML, or
        an already parsed XML element. The `xpath` specifies which element to
        find. See the [introduction] for more details about both the possible
        sources and the supported xpath syntax.

        The keyword fails if more, or less, than one element matches the
        `xpath`. Use [Get Elements] if you want all matching elements to be
        returned.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Get element
            ${element} =    Get Element    ${XML}    second
            ${child} =    Get Element    ${element}    child
        ```

        [Parse XML] is recommended for parsing XML when the whole structure
        is needed. It must be used if there is a need to configure how XML
        namespaces are handled.

        Many other keywords use this keyword internally, and keywords modifying
        XML are typically documented to both to modify the given source and
        to return it. Modifying the source does not apply if the source is
        given as a string. The XML structure parsed based on the string and
        then modified is nevertheless returned.
        """
        elements = self.get_elements(source, xpath)
        if len(elements) != 1:
            self._raise_wrong_number_of_matches(len(elements), xpath)
        return elements[0]

    def _raise_wrong_number_of_matches(
        self, count: int, xpath: str, message: "str | None" = None
    ) -> NoReturn:
        if not message:
            message = self._wrong_number_of_matches(count, xpath)
        raise AssertionError(message)

    def _wrong_number_of_matches(self, count: int, xpath: str) -> str:
        if not count:
            return f"No element matching '{xpath}' found."
        if count == 1:
            return f"One element matching '{xpath}' found."
        return f"Multiple elements ({count}) matching '{xpath}' found."

    def get_elements(self, source: Source, xpath: str) -> "list[Element]":
        """Returns a list of elements in the `source` matching the `xpath`.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression selecting elements to return.

        Returns:
            A list of matching elements. An empty list if none match.

        The `source` can be a path to an XML file, a string containing XML, or
        an already parsed XML element. The `xpath` specifies which element to
        find. See the [introduction] for more details.

        Elements matching the `xpath` are returned as a list. If no elements
        match, an empty list is returned. Use [Get Element] if you want to get
        exactly one match.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Get elements
            ${children} =    Get Elements    ${XML}    third/child
            Length Should Be    ${children}    2
            ${children} =    Get Elements    ${XML}    first/child
            Should Be Empty    ${children}
        ```
        """
        if isinstance(source, (str, bytes, Path)):
            source = self.parse_xml(source)
        finder = ElementFinder(self.etree, self.modern_etree, self.lxml_etree)
        return finder.find_all(source, xpath)

    def get_child_elements(self, source: Source, xpath: str = ".") -> "list[Element]":
        """Returns the child elements of the specified element as a list.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression selecting the parent element.

        Returns:
            A list of direct child elements.

        The element whose children to return is specified using `source` and
        `xpath`. They have exactly the same semantics as with the [Get Element]
        keyword.

        All the direct child elements of the specified element are returned.
        If the element has no children, an empty list is returned.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Get child elements
            ${children} =    Get Child Elements    ${XML}
            Length Should Be    ${children}    4
            ${children} =    Get Child Elements    ${XML}    xpath=first
            Should Be Empty    ${children}
        ```
        """
        return list(self.get_element(source, xpath))

    def get_element_count(self, source: Source, xpath: str = ".") -> int:
        """Returns and logs how many elements the given `xpath` matches.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression selecting elements to count.

        Returns:
            The number of matching elements.

        Arguments `source` and `xpath` have exactly the same semantics as
        with [Get Elements] keyword that this keyword uses internally.

        See also [Element Should Exist] and [Element Should Not Exist].
        """
        count = len(self.get_elements(source, xpath))
        logger.info(f"{count} element{s(count)} matched '{xpath}'.")
        return count

    def element_should_exist(
        self,
        source: Source,
        xpath: str = ".",
        message: "str | None" = None,
    ):
        """Verifies that one or more element match the given `xpath`.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression to match.
            message: Optional custom error message.

        Arguments `source` and `xpath` have exactly the same semantics as
        with [Get Elements] keyword. Keyword passes if the `xpath` matches
        one or more elements in the `source`. The default error message can
        be overridden with the `message` argument.

        See also [Element Should Not Exist] as well as [Get Element Count]
        that this keyword uses internally.
        """
        count = self.get_element_count(source, xpath)
        if not count:
            self._raise_wrong_number_of_matches(count, xpath, message)

    def element_should_not_exist(
        self,
        source: Source,
        xpath: str = ".",
        message: "str | None" = None,
    ):
        """Verifies that no element match the given `xpath`.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression to match.
            message: Optional custom error message.

        Arguments `source` and `xpath` have exactly the same semantics as
        with [Get Elements] keyword. Keyword fails if the `xpath` matches any
        element in the `source`. The default error message can be overridden
        with the `message` argument.

        See also [Element Should Exist] as well as [Get Element Count]
        that this keyword uses internally.
        """
        count = self.get_element_count(source, xpath)
        if count:
            self._raise_wrong_number_of_matches(count, xpath, message)

    def get_element_text(
        self,
        source: Source,
        xpath: str = ".",
        normalize_whitespace: bool = False,
    ) -> str:
        """Returns all text of the element, possibly whitespace normalized.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression selecting the element.
            normalize_whitespace: Normalize whitespace in the returned text.

        Returns:
            All text of the element, including text of child elements.

        The element whose text to return is specified using `source` and `xpath`.
        They have exactly the same semantics as with the [Get Element] keyword.

        This keyword returns all the text of the specified element, including
        all the text its children and grandchildren contain. If the element
        has no text, an empty string is returned. The returned text is thus not
        always the same as the [text] attribute of the element.

        All whitespace, including newlines and indentation, inside the element
        is returned as-is. If `normalize_whitespace` is given a true value,
        then leading and trailing whitespace is stripped, newlines and tabs
        converted to spaces, and multiple spaces collapsed into one. This is
        especially useful when dealing with HTML data.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Get element text
            ${text} =    Get Element Text    ${XML}    first
            Should Be Equal    ${text}    text
            ${text} =    Get Element Text    ${XML}    second/child
            Should Be Empty    ${text}
            ${paragraph} =    Get Element    ${XML}    html/p
            ${text} =    Get Element Text    ${paragraph}    normalize_whitespace=True
            Should Be Equal    ${text}    Text with bold and italics.
        ```

        See also [Get Elements Texts], [Element Text Should Be] and
        [Element Text Should Match].
        """
        element = self.get_element(source, xpath)
        text = "".join(self._yield_texts(element))
        if normalize_whitespace:
            text = self._normalize_whitespace(text)
        return text

    def _yield_texts(self, element: Element, top: bool = True) -> "Iterator[str]":
        if element.text:
            yield element.text
        for child in element:
            yield from self._yield_texts(child, top=False)
        if element.tail and not top:
            yield element.tail

    def _normalize_whitespace(self, text: str) -> str:
        return " ".join(text.split())

    def get_elements_texts(
        self,
        source: Source,
        xpath: str,
        normalize_whitespace: bool = False,
    ) -> "list[str]":
        """Returns text of all elements matching `xpath` as a list.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression selecting elements.
            normalize_whitespace: Normalize whitespace in returned texts.

        Returns:
            A list of texts of the matched elements.

        The elements whose text to return is specified using `source` and `xpath`.
        They have exactly the same semantics as with the [Get Elements] keyword.

        The text of the matched elements is returned using the same logic
        as with [Get Element Text]. This includes optional whitespace
        normalization using the `normalize_whitespace` option.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Get elements texts
            @{texts} =    Get Elements Texts    ${XML}    third/child    normalize_whitespace=True
            Length Should Be    ${texts}    2
            Should Be Equal    ${texts}[0]    more text
            Should Be Equal    ${texts}[1]    ${EMPTY}
        ```
        """
        return [
            self.get_element_text(elem, normalize_whitespace=normalize_whitespace)
            for elem in self.get_elements(source, xpath)
        ]

    def element_text_should_be(
        self,
        source: Source,
        expected: str,
        xpath: str = ".",
        normalize_whitespace: bool = False,
        message: "str | None" = None,
    ):
        """Verifies that the text of the specified element is `expected`.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            expected: Expected text of the element.
            xpath: XPath expression selecting the element.
            normalize_whitespace: Normalize whitespace before comparison.
            message: Optional custom error message.

        The element whose text is verified is specified using `source` and
        `xpath`. They have exactly the same semantics as with the [Get Element]
        keyword.

        The text to verify is got from the specified element using the same
        logic as with [Get Element Text]. This includes optional whitespace
        normalization using the `normalize_whitespace` option.

        The keyword passes if the text of the element is equal to the
        `expected` value, and otherwise it fails. The default error message
        can be overridden with the `message` argument.  Use `Element Text
        Should Match` to verify the text against a pattern instead of an exact
        value.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Element text should be
            Element Text Should Be    ${XML}    text    xpath=first
            Element Text Should Be    ${XML}    ${EMPTY}    xpath=second/child
            ${paragraph} =    Get Element    ${XML}    xpath=html/p
            Element Text Should Be    ${paragraph}    Text with bold and italics.    normalize_whitespace=True
        ```
        """
        text = self.get_element_text(source, xpath, normalize_whitespace)
        should_be_equal(text, expected, message, values=False)

    def element_text_should_match(
        self,
        source: Source,
        pattern: str,
        xpath: str = ".",
        normalize_whitespace: bool = False,
        message: "str | None" = None,
    ):
        """Verifies that the text of the specified element matches `expected`.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            pattern: Pattern the element text must match.
            xpath: XPath expression selecting the element.
            normalize_whitespace: Normalize whitespace before matching.
            message: Optional custom error message.

        This keyword works exactly like [Element Text Should Be] except that
        the expected value can be given as a pattern that the text of the
        element must match.

        Pattern matching is similar as matching files in a shell with
        `*`, `?` and `[chars]` acting as wildcards. See the
        [Pattern matching] section for more information.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Element text should match
            Element Text Should Match    ${XML}    t???    xpath=first
            ${paragraph} =    Get Element    ${XML}    xpath=html/p
            Element Text Should Match    ${paragraph}    Text with * and *.    normalize_whitespace=True
        ```
        """
        text = self.get_element_text(source, xpath, normalize_whitespace)
        should_match(text, pattern, message, values=False)

    def get_element_attribute(
        self,
        source: Source,
        name: str,
        xpath: str = ".",
        default: object = None,
    ) -> "str | object":
        """Returns the named attribute of the specified element.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            name: Name of the attribute to return.
            xpath: XPath expression selecting the element.
            default: Value returned if the attribute does not exist.

        Returns:
            The attribute value, or ``default`` if the attribute is missing.

        The element whose attribute to return is specified using `source` and `xpath`.
        They have exactly the same semantics as with the [Get Element] keyword.

        The value of the attribute `name` of the specified element is returned.
        If the element does not have such element, the `default` value is
        returned instead.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Get element attribute
            ${attribute} =    Get Element Attribute    ${XML}    id    xpath=first
            Should Be Equal    ${attribute}    1
            ${attribute} =    Get Element Attribute    ${XML}    xx    xpath=first    default=value
            Should Be Equal    ${attribute}    value
        ```

        See also [Get Element Attributes], [Element Attribute Should Be],
        [Element Attribute Should Match] and [Element Should Not Have Attribute].
        """
        return self.get_element(source, xpath).get(name, default)

    def get_element_attributes(
        self,
        source: Source,
        xpath: str = ".",
    ) -> "dict[str, str]":
        """Returns all attributes of the specified element.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression selecting the element.

        Returns:
            A dictionary of all attributes of the element.

        The element whose attributes to return is specified using `source` and
        `xpath`. They have exactly the same semantics as with the [Get Element]
        keyword.

        Attributes are returned as a Python dictionary. It is a copy of the
        original attributes so modifying it has no effect on the XML structure.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Get element attributes
            ${attributes} =    Get Element Attributes    ${XML}    first
            Should Be Equal    ${attributes}[id]    1
            ${attributes} =    Get Element Attributes    ${XML}    third
            Should Be Empty    ${attributes}
        ```

        Use [Get Element Attribute] to get the value of a single attribute.
        """
        return dict(self.get_element(source, xpath).attrib)

    def element_attribute_should_be(
        self,
        source: Source,
        name: str,
        expected: "str | None",
        xpath: str = ".",
        message: "str | None" = None,
    ):
        """Verifies that the specified attribute is `expected`.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            name: Name of the attribute to verify.
            expected: Expected attribute value.
            xpath: XPath expression selecting the element.
            message: Optional custom error message.

        The element whose attribute is verified is specified using `source`
        and `xpath`. They have exactly the same semantics as with
        [Get Element] keyword.

        The keyword passes if the attribute `name` of the element is equal to
        the `expected` value, and otherwise it fails. The default error
        message can be overridden with the `message` argument.

        To test that the element does not have a certain attribute, Python
        `None` (i.e. variable `${NONE}`) can be used as the expected value.
        A cleaner alternative is using [Element Should Not Have Attribute].

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Element attribute should be
            Element Attribute Should Be    ${XML}    id    1    xpath=first
            Element Attribute Should Be    ${XML}    id    ${NONE}
        ```

        See also [Element Attribute Should Match] and [Get Element Attribute].
        """
        attr = self.get_element_attribute(source, name, xpath)
        should_be_equal(attr, expected, message, values=False)

    def element_attribute_should_match(
        self,
        source: Source,
        name: str,
        pattern: str,
        xpath: str = ".",
        message: "str | None" = None,
    ):
        """Verifies that the specified attribute matches `expected`.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            name: Name of the attribute to verify.
            pattern: Pattern the attribute value must match.
            xpath: XPath expression selecting the element.
            message: Optional custom error message.

        This keyword works exactly like [Element Attribute Should Be] except
        that the expected value can be given as a pattern that the attribute of
        the element must match.

        Pattern matching is similar as matching files in a shell with
        `*`, `?` and `[chars]` acting as wildcards. See the
        [Pattern matching] section for more information.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Element attribute should match
            Element Attribute Should Match    ${XML}    id    ?    xpath=first
            Element Attribute Should Match    ${XML}    id    c*d    xpath=third/second
        ```
        """
        attr = self.get_element_attribute(source, name, xpath)
        if attr is None:
            raise AssertionError(f"Attribute '{name}' does not exist.")
        should_match(attr, pattern, message, values=False)

    def element_should_not_have_attribute(
        self,
        source: Source,
        name: str,
        xpath: str = ".",
        message: "str | None" = None,
    ):
        """Verifies that the specified element does not have attribute `name`.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            name: Name of the attribute that must not exist.
            xpath: XPath expression selecting the element.
            message: Optional custom error message.

        The element whose attribute is verified is specified using `source`
        and `xpath`. They have exactly the same semantics as with
        [Get Element] keyword.

        The keyword fails if the specified element has attribute `name`. The
        default error message can be overridden with the `message` argument.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Element should not have attribute
            Element Should Not Have Attribute    ${XML}    id
            Element Should Not Have Attribute    ${XML}    xxx    xpath=first
        ```

        See also [Get Element Attribute], [Get Element Attributes],
        [Element Text Should Be] and [Element Text Should Match].
        """
        attr = self.get_element_attribute(source, name, xpath)
        if attr is not None:
            raise AssertionError(
                message or f"Attribute '{name}' exists and has value '{attr}'."
            )

    def elements_should_be_equal(
        self,
        source: Source,
        expected: Source,
        exclude_children: bool = False,
        normalize_whitespace: bool = False,
        sort_children: bool = False,
    ):
        """Verifies that the given `source` element is equal to `expected`.

        Args:
            source: Element to compare.
            expected: Expected element as a path, string, or parsed element.
            exclude_children: Exclude child elements from comparison.
            normalize_whitespace: Normalize whitespace in text comparison.
            sort_children: Sort child elements by tag name before comparison.

        Both `source` and `expected` can be given as a path to an XML file,
        as a string containing XML, or as an already parsed XML element
        structure. See [introduction] for more information about parsing XML in
        general.

        The keyword passes if the `source` element and `expected` element
        are equal. This includes testing the tag names, texts, and attributes
        of the elements. By default, also child elements are verified the same
        way, but this can be disabled by setting `exclude_children` to a
        true value. Child elements are expected to
        be in the same order, but that can be changed by giving `sort_children`
        a true value. Notice that elements are sorted solely based on tag names.

        All texts inside the given elements are verified, but possible text
        outside them is not. By default, texts must match exactly, but setting
        `normalize_whitespace` to a true value makes text verification
        independent on newlines, tabs, and the amount of spaces. For more
        details about handling text see [Get Element Text] keyword and
        discussion about elements' [text] and [tail] attributes in the
        [introduction].

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Elements should be equal
            ${first} =    Get Element    ${XML}    first
            Elements Should Be Equal    ${first}    <first id="1">text</first>
            ${p} =    Get Element    ${XML}    html/p
            Elements Should Be Equal    ${p}    <p>Text with <b>bold</b> and <i>italics</i>.</p>    normalize_whitespace=True
            Elements Should Be Equal    ${p}    <p>Text with</p>    exclude    normalize
        ```

        The last example may look a bit strange because the `<p>` element
        only has text `Text with`. The reason is that rest of the text
        inside `<p>` actually belongs to the child elements. This includes
        the `.` at the end that is the [tail] text of the `<i>` element.

        See also [Elements Should Match].

        `sort_children` is new in Robot Framework 7.0.
        """
        self._compare_elements(
            source,
            expected,
            should_be_equal,
            exclude_children,
            sort_children,
            normalize_whitespace,
        )

    def elements_should_match(
        self,
        source: Source,
        expected: Source,
        exclude_children: bool = False,
        normalize_whitespace: bool = False,
        sort_children: bool = False,
    ):
        """Verifies that the given `source` element matches `expected`.

        Args:
            source: Element to compare.
            expected: Expected element as a path, string, or parsed element.
            exclude_children: Exclude child elements from comparison.
            normalize_whitespace: Normalize whitespace in text comparison.
            sort_children: Sort child elements by tag name before comparison.

        This keyword works exactly like [Elements Should Be Equal] except that
        texts and attribute values in the expected value can be given as
        patterns.

        Pattern matching is similar as matching files in a shell with
        `*`, `?` and `[chars]` acting as wildcards. See the
        [Pattern matching] section for more information.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Elements should match
            ${first} =    Get Element    ${XML}    first
            Elements Should Match    ${first}    <first id="?">*</first>
        ```

        See [Elements Should Be Equal] for more examples.
        """
        self._compare_elements(
            source,
            expected,
            should_match,
            exclude_children,
            sort_children,
            normalize_whitespace,
        )

    def _compare_elements(
        self,
        source: Source,
        expected: Source,
        comparator: Callable[[Any, Any, str], None],
        exclude_children: bool,
        sort_children: bool,
        normalize_whitespace: bool,
    ):
        normalizer = self._normalize_whitespace if normalize_whitespace else None
        sorter = self._sort_children if sort_children else None
        element_comparator = ElementComparator(
            comparator, normalizer, sorter, exclude_children
        )
        element_comparator.compare(self.get_element(source), self.get_element(expected))

    def _sort_children(self, element: Element):
        tails = [child.tail for child in element]
        element[:] = sorted(element, key=lambda child: child.tag)
        for child, tail in zip(element, tails):
            child.tail = tail

    def set_element_tag(self, source: Source, tag: str, xpath: str = ".") -> Element:
        """Sets the tag of the specified element.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            tag: New tag name.
            xpath: XPath expression selecting the element to modify.

        Returns:
            The root of the modified XML structure.

        The element whose tag to set is specified using `source` and
        `xpath`. They have exactly the same semantics as with the [Get Element]
        keyword. The resulting XML structure is returned, and if the `source`
        is an already parsed XML structure, it is also modified in place.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Set element tag
            ${root} =    Parse XML    ${XML}
            Set Element Tag    ${root}    new
            Should Be Equal    ${root.tag}    new
            Set Element Tag    ${root}    xxx    xpath=second/child
            Element Should Exist    ${root}    second/xxx
            Element Should Not Exist    ${root}    second/child
        ```

        Can only set the tag of a single element. Use [Set Elements Tag] to set
        the tag of multiple elements in one call.
        """
        source = self.get_element(source)
        self.get_element(source, xpath).tag = tag
        return source

    def set_elements_tag(self, source: Source, tag: str, xpath: str = ".") -> Element:
        """Sets the tag of the specified elements.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            tag: New tag name.
            xpath: XPath expression selecting elements to modify.

        Returns:
            The root of the modified XML structure.

        Like [Set Element Tag] but sets the tag of all elements matching
        the given `xpath`.
        """
        source = self.get_element(source)
        for elem in self.get_elements(source, xpath):
            self.set_element_tag(elem, tag)
        return source

    def set_element_text(
        self,
        source: Source,
        text: "str | None" = None,
        tail: "str | None" = None,
        xpath: str = ".",
    ) -> Element:
        """Sets text and/or tail text of the specified element.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            text: New text for the element.
            tail: New tail text for the element.
            xpath: XPath expression selecting the element to modify.

        Returns:
            The root of the modified XML structure.

        The element whose text to set is specified using `source` and
        `xpath`. They have exactly the same semantics as with the [Get Element]
        keyword. The resulting XML structure is returned, and if the `source`
        is an already parsed XML structure, it is also modified in place.

        Element's text and tail text are changed only if new `text` and/or
        `tail` values are given. See [Element attributes] section for more
        information about [text] and [tail] in general.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Set element text
            ${root} =    Parse XML    ${XML}
            Set Element Text    ${root}    new text    xpath=first
            Element Text Should Be    ${root}    new text    xpath=first
            Set Element Text    ${root}    tail=&    xpath=html/p/b
            Element Text Should Be    ${root}    Text with bold&italics.    xpath=html/p    normalize_whitespace=True
            Set Element Text    ${root}    slanted    !!    xpath=html/p/i
            Element Text Should Be    ${root}    Text with bold&slanted!!    xpath=html/p    normalize_whitespace=True
        ```

        Can only set the text/tail of a single element. Use [Set Elements Text]
        to set the text/tail of multiple elements in one call.
        """
        source = self.get_element(source)
        element = self.get_element(source, xpath)
        if text is not None:
            element.text = text
        if tail is not None:
            element.tail = tail
        return source

    def set_elements_text(
        self,
        source: Source,
        text: "str | None" = None,
        tail: "str | None" = None,
        xpath: str = ".",
    ) -> Element:
        """Sets text and/or tail text of the specified elements.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            text: New text for the elements.
            tail: New tail text for the elements.
            xpath: XPath expression selecting elements to modify.

        Returns:
            The root of the modified XML structure.

        Like [Set Element Text] but sets the text or tail of all elements
        matching the given `xpath`.
        """
        source = self.get_element(source)
        for elem in self.get_elements(source, xpath):
            self.set_element_text(elem, text, tail)
        return source

    def set_element_attribute(
        self,
        source: Source,
        name: str,
        value: str,
        xpath: str = ".",
    ) -> Element:
        """Sets attribute `name` of the specified element to `value`.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            name: Name of the attribute to set.
            value: Value to assign to the attribute.
            xpath: XPath expression selecting the element to modify.

        Returns:
            The root of the modified XML structure.

        The element whose attribute to set is specified using `source` and
        `xpath`. They have exactly the same semantics as with the [Get Element]
        keyword. The resulting XML structure is returned, and if the `source`
        is an already parsed XML structure, it is also modified in place.

        It is possible to both set new attributes and to overwrite existing.
        Use [Remove Element Attribute] or [Remove Element Attributes] for
        removing them.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Set element attribute
            ${root} =    Parse XML    ${XML}
            Set Element Attribute    ${root}    attr    value
            Element Attribute Should Be    ${root}    attr    value
            Set Element Attribute    ${root}    id    new    xpath=first
            Element Attribute Should Be    ${root}    id    new    xpath=first
        ```

        Can only set an attribute of a single element. Use `Set Elements
        Attribute` to set an attribute of multiple elements in one call.
        """
        if not name:
            raise RuntimeError("Attribute name can not be empty.")
        source = self.get_element(source)
        self.get_element(source, xpath).attrib[name] = value
        return source

    def set_elements_attribute(
        self,
        source: Source,
        name: str,
        value: str,
        xpath: str = ".",
    ) -> Element:
        """Sets attribute `name` of the specified elements to `value`.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            name: Name of the attribute to set.
            value: Value to assign to the attribute.
            xpath: XPath expression selecting elements to modify.

        Returns:
            The root of the modified XML structure.

        Like [Set Element Attribute] but sets the attribute of all elements
        matching the given `xpath`.
        """
        source = self.get_element(source)
        for elem in self.get_elements(source, xpath):
            self.set_element_attribute(elem, name, value)
        return source

    def remove_element_attribute(
        self,
        source: Source,
        name: str,
        xpath: str = ".",
    ) -> Element:
        """Removes attribute `name` from the specified element.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            name: Name of the attribute to remove.
            xpath: XPath expression selecting the element to modify.

        Returns:
            The root of the modified XML structure.

        The element whose attribute to remove is specified using `source` and
        `xpath`. They have exactly the same semantics as with the [Get Element]
        keyword. The resulting XML structure is returned, and if the `source`
        is an already parsed XML structure, it is also modified in place.

        It is not a failure to remove a non-existing attribute. Use `Remove
        Element Attributes[ to remove all attributes and ]Set Element Attribute`
        to set them.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Remove element attribute
            ${root} =    Parse XML    ${XML}
            Remove Element Attribute    ${root}    id    xpath=first
            Element Should Not Have Attribute    ${root}    id    xpath=first
        ```

        Can only remove an attribute from a single element. Use `Remove Elements
        Attribute` to remove an attribute of multiple elements in one call.
        """
        source = self.get_element(source)
        attrib = self.get_element(source, xpath).attrib
        if name in attrib:
            attrib.pop(name)
        return source

    def remove_elements_attribute(
        self,
        source: Source,
        name: str,
        xpath: str = ".",
    ) -> Element:
        """Removes attribute `name` from the specified elements.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            name: Name of the attribute to remove.
            xpath: XPath expression selecting elements to modify.

        Returns:
            The root of the modified XML structure.

        Like [Remove Element Attribute] but removes the attribute of all
        elements matching the given `xpath`.
        """
        source = self.get_element(source)
        for elem in self.get_elements(source, xpath):
            self.remove_element_attribute(elem, name)
        return source

    def remove_element_attributes(self, source: Source, xpath: str = ".") -> Element:
        """Removes all attributes from the specified element.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression selecting the element to modify.

        Returns:
            The root of the modified XML structure.

        The element whose attributes to remove is specified using `source` and
        `xpath`. They have exactly the same semantics as with the [Get Element]
        keyword. The resulting XML structure is returned, and if the `source`
        is an already parsed XML structure, it is also modified in place.

        Use [Remove Element Attribute] to remove a single attribute and
        [Set Element Attribute] to set them.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Remove element attributes
            ${root} =    Parse XML    ${XML}
            Remove Element Attributes    ${root}    xpath=first
            Element Should Not Have Attribute    ${root}    id    xpath=first
        ```

        Can only remove attributes from a single element. Use `Remove Elements
        Attributes` to remove all attributes of multiple elements in one call.
        """
        source = self.get_element(source)
        self.get_element(source, xpath).attrib.clear()
        return source

    def remove_elements_attributes(self, source: Source, xpath: str = ".") -> Element:
        """Removes all attributes from the specified elements.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression selecting elements to modify.

        Returns:
            The root of the modified XML structure.

        Like [Remove Element Attributes] but removes all attributes of all
        elements matching the given `xpath`.
        """
        source = self.get_element(source)
        for elem in self.get_elements(source, xpath):
            self.remove_element_attributes(elem)
        return source

    def add_element(
        self,
        source: Source,
        element: Source,
        index: "int | None" = None,
        xpath: str = ".",
    ) -> Element:
        """Adds a child element to the specified element.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            element: Element to add as a path, string, or parsed element.
            index: Optional position among child elements.
            xpath: XPath expression selecting the parent element.

        Returns:
            The root of the modified XML structure.

        The element to whom to add the new element is specified using `source`
        and `xpath`. They have exactly the same semantics as with the [Get Element]
        keyword. The resulting XML structure is returned, and if the `source`
        is an already parsed XML structure, it is also modified in place.

        The `element` to add can be specified as a path to an XML file or
        as a string containing XML, or it can be an already parsed XML element.
        The element is copied before adding so modifying either the original
        or the added element has no effect on the other.
        The element is added as the last child by default, but a custom index
        can be used to alter the position. Indices start from zero (0 = first
        position, 1 = second position, etc.), and negative numbers refer to
        positions at the end (-1 = second last position, -2 = third last, etc.).

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Add element
            ${root} =    Parse XML    ${XML}
            Add Element    ${root}    <new id="x"><c1/></new>
            Add Element    ${root}    <c2/>    xpath=new
            Add Element    ${root}    <c3/>    index=1    xpath=new
            ${new} =    Get Element    ${root}    new
            Elements Should Be Equal    ${new}    <new id="x"><c1/><c3/><c2/></new>
        ```

        Use [Remove Element] or [Remove Elements] to remove elements.
        """
        source = self.get_element(source)
        parent = self.get_element(source, xpath)
        element = self.copy_element(element)
        if index is None:
            parent.append(element)
        else:
            parent.insert(int(index), element)
        return source

    def remove_element(
        self,
        source: Source,
        xpath: str = "",
        remove_tail: bool = False,
    ) -> Element:
        """Removes the element matching `xpath` from the `source` structure.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression selecting the element to remove.
            remove_tail: Remove the element's tail text.

        Returns:
            The root of the modified XML structure.

        Raises:
            AssertionError: If ``xpath`` does not match exactly one element.

        The element to remove from the `source` is specified with `xpath`
        using the same semantics as with the [Get Element] keyword. The resulting
        XML structure is returned, and if the `source` is an already parsed
        XML structure, it is also modified in place.

        The keyword fails if `xpath` does not match exactly one element.
        Use [Remove Elements] to remove all matched elements.

        Element's tail text is not removed by default, but that can be changed
        by giving `remove_tail` a true value. See the [Element attributes]
        section for more information about `tail` in general.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Remove element
            ${root} =    Parse XML    ${XML}
            Remove Element    ${root}    xpath=second
            Element Should Not Exist    ${root}    xpath=second
            Remove Element    ${root}    xpath=html/p/b    remove_tail=True
            Element Text Should Be    ${root}    Text with italics.    xpath=html/p    normalize_whitespace=True
        ```
        """
        source = self.get_element(source)
        self._remove_element(source, self.get_element(source, xpath), remove_tail)
        return source

    def remove_elements(
        self,
        source: Source,
        xpath: str = "",
        remove_tail: bool = False,
    ) -> Element:
        """Removes all elements matching `xpath` from the `source` structure.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression selecting elements to remove.
            remove_tail: Remove tail text of removed elements.

        Returns:
            The root of the modified XML structure.

        The elements to remove from the `source` are specified with `xpath`
        using the same semantics as with [Get Elements] keyword. The resulting
        XML structure is returned, and if the `source` is an already parsed
        XML structure, it is also modified in place.

        It is not a failure if `xpath` matches no elements. Use `Remove
        Element` to remove exactly one element.

        Element's tail text is not removed by default, but that can be changed
        by using `remove_tail` argument similarly as with [Remove Element].

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Remove elements
            ${root} =    Parse XML    ${XML}
            Remove Elements    ${root}    xpath=*/child
            Element Should Not Exist    ${root}    xpath=second/child
            Element Should Not Exist    ${root}    xpath=third/child
        ```
        """
        source = self.get_element(source)
        for element in self.get_elements(source, xpath):
            self._remove_element(source, element, remove_tail)
        return source

    def _remove_element(
        self,
        root: Element,
        element: Element,
        remove_tail: bool = False,
    ):
        parent = self._find_parent(root, element)
        if not remove_tail:
            self._preserve_tail(element, parent)
        parent.remove(element)

    def _find_parent(self, root: Element, element: Element) -> Element:
        for parent in root.iter():
            for child in parent:
                if child is element:
                    return parent
        raise RuntimeError("Cannot remove root element.")

    def _preserve_tail(self, element: Element, parent: Element):
        if not element.tail:
            return
        index = list(parent).index(element)
        if index == 0:
            parent.text = (parent.text or "") + element.tail
        else:
            sibling = parent[index - 1]
            sibling.tail = (sibling.tail or "") + element.tail

    def clear_element(
        self,
        source: Source,
        xpath: str = ".",
        clear_tail: bool = False,
    ) -> Element:
        """Clears the contents of the specified element.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression selecting the element to clear.
            clear_tail: Remove the element's tail text.

        Returns:
            The root of the modified XML structure.

        The element to clear is specified using `source` and `xpath`. They
        have exactly the same semantics as with the [Get Element] keyword.
        The resulting XML structure is returned, and if the `source` is
        an already parsed XML structure, it is also modified in place.

        Clearing the element means removing its text, attributes, and children.
        Element's tail text is not removed by default, but that can be changed
        by giving `clear_tail` a true value. See the [Element attributes]
        section for more information about `tail` in general.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Clear element
            ${root} =    Parse XML    ${XML}
            Clear Element    ${root}    xpath=first
            ${first} =    Get Element    ${root}    xpath=first
            Elements Should Be Equal    ${first}    <first/>
            Clear Element    ${root}    xpath=html/p/b    clear_tail=True
            Element Text Should Be    ${root}    Text with italics.    xpath=html/p    normalize_whitespace=True
            Clear Element    ${root}
            Elements Should Be Equal    ${root}    <example/>
        ```

        Use [Remove Element] to remove the whole element.
        """
        source = self.get_element(source)
        element = self.get_element(source, xpath)
        tail = element.tail
        element.clear()
        if not clear_tail:
            element.tail = tail
        return source

    def copy_element(self, source: Source, xpath: str = ".") -> Element:
        """Returns a copy of the specified element.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression selecting the element to copy.

        Returns:
            A deep copy of the element.

        The element to copy is specified using `source` and `xpath`. They
        have exactly the same semantics as with the [Get Element] keyword.

        If the copy or the original element is modified afterward, the changes
        have no effect on the other.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Copy element
            ${root} =    Parse XML    ${XML}
            ${elem} =    Get Element    ${root}    xpath=first
            ${copy1} =    Copy Element    ${elem}
            ${copy2} =    Copy Element    ${root}    xpath=first
            Set Element Text    ${root}    new text    xpath=first
            Set Element Attribute    ${copy1}    id    new
            Elements Should Be Equal    ${elem}     <first id="1">new text</first>
            Elements Should Be Equal    ${copy1}    <first id="new">text</first>
            Elements Should Be Equal    ${copy2}    <first id="1">text</first>
        ```
        """
        return copy.deepcopy(self.get_element(source, xpath))

    def element_to_string(
        self,
        source: Source,
        xpath: str = ".",
        encoding: "str | None" = None,
    ) -> "bytes | str":
        """Returns the string representation of the specified element.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            xpath: XPath expression selecting the element to convert.
            encoding: Optional encoding. If given, returns bytes.

        Returns:
            String or bytes representation of the element.

        The element to convert to a string is specified using `source` and `xpath`.
        They have exactly the same semantics as with the [Get Element] keyword.

        The string is returned as Unicode by default. If `encoding` argument
        is given any value, the string is returned as bytes in the specified
        encoding. The resulting string never contains the XML declaration.

        See also [Log Element] and [Save XML].
        """
        source = self.get_element(source, xpath)
        if self.lxml_etree:
            source = self._ns_stripper.unstrip(source)
        string = self.etree.tostring(source, encoding="UTF-8").decode("UTF-8")
        string = re.sub(r"^<\?xml .*\?>", "", string).strip()
        if encoding:
            string = string.encode(encoding)
        return string

    def log_element(
        self,
        source: Source,
        level: logger.LogLevel = "INFO",
        xpath: str = ".",
    ) -> str:
        """Logs the string representation of the specified element.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            level: Log level to use.
            xpath: XPath expression selecting the element to log.

        Returns:
            The logged string representation of the element.

        The element specified with `source` and `xpath` is first converted
        into a string using [Element To String] keyword internally. The
        resulting string is then logged using the given `level`.

        The logged string is also returned.
        """
        string = self.element_to_string(source, xpath)
        logger.write(string, level)
        return string

    def save_xml(
        self,
        source: Source,
        path: Path,
        encoding: str = "UTF-8",
    ):
        """Saves the given element to the specified file.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            path: Path where the XML file is saved.
            encoding: Encoding used when saving the file.

        The element to save is specified with `source` using the same
        semantics as with the [Get Element] keyword.

        The file where the element is saved is denoted with `path` and the
        encoding to use with `encoding`. The resulting file always contains
        the XML declaration.

        The resulting XML file may not be exactly the same as the original:
        - Comments and processing instructions are always stripped.
        - Possible doctype and namespace prefixes are only preserved when
          [using lxml].
        - Other small differences are possible depending on the ElementTree
          or lxml version.

        Use [Element To String] if you just need a string representation of
        the element.
        """
        path = path.absolute()
        elem = self.get_element(source)
        tree = self.etree.ElementTree(elem)
        config: dict[str, object] = {"encoding": encoding}
        if self.modern_etree:
            config["xml_declaration"] = True
        if self.lxml_etree:
            elem = self._ns_stripper.unstrip(elem)
            # https://bugs.launchpad.net/lxml/+bug/1660433
            if tree.docinfo.doctype:  # type: ignore
                config["doctype"] = tree.docinfo.doctype  # type: ignore
            tree = self.etree.ElementTree(elem)
        with open(path, "wb") as output:
            if "doctype" in config:
                output.write(self.etree.tostring(tree, **config))  # type: ignore
            else:
                tree.write(output, **config)  # type: ignore
        logger.info(f'XML saved to <a href="file://{path}">{path}</a>.', html=True)

    def evaluate_xpath(
        self,
        source: Source,
        expression: str,
        context: str = ".",
    ) -> object:
        """Evaluates the given xpath expression and returns results.

        Args:
            source: Path to an XML file, XML string or bytes, or a parsed element.
            expression: XPath expression to evaluate.
            context: XPath expression selecting the context element.

        Returns:
            The result of the xpath evaluation.

        Raises:
            RuntimeError: If the library is not running in lxml mode.

        The element in which context the expression is executed is specified
        using `source` and `context` arguments. They have exactly the same
        semantics as `source` and `xpath` arguments have with the [Get Element]
        keyword.

        The xpath expression to evaluate is given as `expression` argument.
        The result of the evaluation is returned as-is.

        Examples using the `${XML}` structure from the [Example] section:

        ```robotframework
        *** Test Cases ***
        Evaluate xpath
            ${count} =    Evaluate Xpath    ${XML}    count(third/*)
            Should Be Equal    ${count}    ${3}
            ${text} =    Evaluate Xpath    ${XML}    string(descendant::second[last()]/@id)
            Should Be Equal    ${text}    child
            ${bold} =    Evaluate Xpath    ${XML}    boolean(preceding-sibling::*[1] = 'bold')    context=html/p/i
            Should Be Equal    ${bold}    ${True}
        ```

        This keyword works only if lxml mode is taken into use when [importing]
        the library.
        """
        if not self.lxml_etree:
            raise RuntimeError("'Evaluate Xpath' keyword only works in lxml mode.")
        return self.get_element(source, context).xpath(expression)  # type: ignore


class NameSpaceStripper:

    def __init__(self, etree, lxml_etree: bool = False):
        self.etree = etree
        self.lxml_tree = lxml_etree

    def strip(
        self,
        elem: Element,
        preserve: bool = True,
        current_ns: "str | None" = None,
        top: bool = True,
    ):
        if elem.tag.startswith("{") and "}" in elem.tag:
            ns, elem.tag = elem.tag[1:].split("}", 1)
            if preserve and ns != current_ns:
                elem.attrib["xmlns"] = ns
                current_ns = ns
        elif current_ns:
            elem.attrib["xmlns"] = ""
            current_ns = None
        for child in elem:
            self.strip(child, preserve, current_ns, top=False)
        if top and not preserve and self.lxml_tree:
            self.etree.cleanup_namespaces(elem)  # type: ignore

    def unstrip(
        self,
        elem: Element,
        current_ns: "str | None" = None,
        copied: bool = False,
    ) -> Element:
        if not copied:
            elem = copy.deepcopy(elem)
        ns = elem.attrib.pop("xmlns", current_ns)
        if ns:
            elem.tag = f"{{{ns}}}{elem.tag}"
        for child in elem:
            self.unstrip(child, ns, copied=True)
        return elem


class ElementFinder:

    def __init__(
        self,
        etree,
        modern: bool = True,
        lxml: bool = False,
    ):
        self.etree = etree
        self.modern = modern
        self.lxml = lxml

    def find_all(self, elem: Element, xpath: str) -> "list[Element]":
        xpath = self._get_xpath(xpath)
        if xpath == ".":  # ET < 1.3 does not support '.' alone.
            return [elem]
        if not self.lxml:
            return elem.findall(xpath)
        finder = self.etree.ETXPath(xpath)  # type: ignore
        return finder(elem)

    def _get_xpath(self, xpath: str) -> str:
        if not xpath:
            raise RuntimeError("No xpath given.")
        if self.modern:
            return xpath
        try:
            return str(xpath)
        except UnicodeError:
            if not xpath.replace("/", "").isalnum():
                logger.warn(
                    "XPATHs containing non-ASCII characters and other than tag "
                    "names do not always work with Python versions prior to 2.7. "
                    "Verify results manually and consider upgrading to 2.7."
                )
            return xpath


class Location:

    def __init__(self, path: str, is_root: bool = True):
        self.path = path
        self.is_not_root = not is_root
        self.children: dict[str, int] = {}

    def child(self, tag: str) -> "Location":
        if tag not in self.children:
            self.children[tag] = 1
        else:
            self.children[tag] += 1
            tag += f"[{self.children[tag]}]"
        return Location(f"{self.path}/{tag}", is_root=False)


class ElementComparator:

    def __init__(
        self,
        comparator: Callable[[object, object, str], None],
        normalizer: "Callable[[str], str] | None" = None,
        child_sorter: "Callable[[Element], None] | None" = None,
        exclude_children: bool = False,
    ):
        self.comparator = comparator
        self.normalizer = normalizer or (lambda text: text)
        self.child_sorter = child_sorter
        self.exclude_children = exclude_children

    def compare(
        self,
        actual: Element,
        expected: Element,
        location: "Location | None" = None,
    ):
        if not location:
            location = Location(actual.tag)
        self._compare_tags(actual, expected, location)
        self._compare_attributes(actual, expected, location)
        self._compare_texts(actual, expected, location)
        if location.is_not_root:
            self._compare_tails(actual, expected, location)
        if not self.exclude_children:
            self._compare_children(actual, expected, location)

    def _compare_tags(self, actual: Element, expected: Element, location: Location):
        self._compare(
            actual.tag,
            expected.tag,
            "Different tag name",
            location,
            should_be_equal,
        )

    def _compare(
        self,
        actual: object,
        expected: object,
        message: str,
        location: Location,
        comparator: "Callable[[object, object, str], None] | None" = None,
    ):
        if location.is_not_root:
            message = f"{message} at '{location.path}'"
        if not comparator:
            comparator = self.comparator
        comparator(actual, expected, message)

    def _compare_attributes(
        self,
        actual: Element,
        expected: Element,
        location: Location,
    ):
        self._compare(
            sorted(actual.attrib),
            sorted(expected.attrib),
            "Different attribute names",
            location,
            should_be_equal,
        )
        for key in actual.attrib:
            self._compare(
                actual.attrib[key],
                expected.attrib[key],
                f"Different value for attribute '{key}'",
                location,
            )

    def _compare_texts(self, actual: Element, expected: Element, location: Location):
        self._compare(
            self._text(actual.text),
            self._text(expected.text),
            "Different text",
            location,
        )

    def _text(self, text: str) -> str:
        return self.normalizer(text or "")

    def _compare_tails(self, actual: Element, expected: Element, location: Location):
        self._compare(
            self._text(actual.tail),
            self._text(expected.tail),
            "Different tail text",
            location,
        )

    def _compare_children(self, actual: Element, expected: Element, location: Location):
        self._compare(
            len(actual),
            len(expected),
            "Different number of child elements",
            location,
            should_be_equal,
        )
        if self.child_sorter:
            self.child_sorter(actual)
            self.child_sorter(expected)
        for act, exp in zip(actual, expected):
            self.compare(act, exp, location.child(act.tag))
