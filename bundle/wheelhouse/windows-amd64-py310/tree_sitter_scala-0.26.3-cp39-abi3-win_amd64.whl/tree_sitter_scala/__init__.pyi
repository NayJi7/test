from typing import Final

HIGHLIGHTS_QUERY: Final[str]
LOCALS_QUERY: Final[str]

def language() -> object: ...
